This directory contains the values used for plotting the different figures in this article including the Extended Data Figures. The data for each figure are stored in a separate Excel file marked with figure numbers as they appear in the article.

Source_Data_Figure_1.xls: Location map of the proxy records used in this study sorted by archive.
Source_Data_Figure_2.xls: Spatial-temporal distribution of gridded centennial hydrological proxy anomalies.
Source_Data_Figure_3.xls: Probability density function of reconstructed and simulated Northern Hemisphere hydroclimate and temperature anomalies.
Source_Data_Extended_Data_Figure_1.xls: Estimated correlation decay length values.
Source_Data_Extended_Data_Figure_2.xls: The fraction of land area, expressed as decadal means for 1900�1999, exceeding a given wetness or dryness threshold in the gridded reconstruction, model simulations, and instrumental precipitation data.
Source_Data_Extended_Data_Figure_3.xls: Boxplots showing decadal anomaly values of instrumental data, our gridded reconstruction, drought atlas data, and model simulation of precipitation over the 1900s.
Source_Data_Extended_Data_Figure_4.xls: Correlations between gridded proxy and model hydroclimate anomalies, and gridded hydroclimate temperature proxy anomalies.
Source_Data_Extended_Data_Figure_5.xls: Simulated median values of annual precipitation from six atmosphere�ocean coupled general circulation models.
Source_Data_Extended_Data_Figure_6.xls: Centennial temperature proxy anomalies updated from ref. 15.
Source_Data_Extended_Data_Figure_7.xls: Gradients of proxy-reconstructed and simulated Northern Hemisphere centennial hydroclimate anomalies along three meridional transects for the tenth, twentieth and seventeenth centuries.
Source_Data_Extended_Data_Figure_8.xls: Distribution and density of hydroclimate proxy records.
Source_Data_Extended_Data_Figure_9.xls: Histograms of cross-correlations with kernel density estimate added.
